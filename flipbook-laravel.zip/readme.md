## FlipBook
[![Build Status](https://travis-ci.com/allanbarcelos/flipbook-laravel.svg?token=dwRq4HppRnhZwaEprEz9&branch=master)](https://travis-ci.com/allanbarcelos/flipbook-laravel)
