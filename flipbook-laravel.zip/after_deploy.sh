composer update
php artisan migrate:fresh --seed
